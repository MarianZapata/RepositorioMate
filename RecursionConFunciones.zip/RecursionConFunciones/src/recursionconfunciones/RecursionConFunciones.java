/*Ingresar si es geométrica o aritmética
Ingresar an, r, d, a1*/
package recursionconfunciones;

import java.util.Scanner;


public class RecursionConFunciones {

    
    public static void main(String[] args) {
        
     Scanner entrada = new Scanner (System.in);
    
        int n, a1, d, r;
       
        System.out.println("Ingresar si desea los resultados de una sucesión A.Aritmética o G.Geométrica");
        String letra = entrada.nextLine();
               
        switch (letra){
            
            case "A":
            case "a":
                System.out.println("Ingrese n, a1 y d");
                n = entrada.nextInt();
                a1 = entrada.nextInt();
                d = entrada.nextInt();
                generar_numerosAritmetica(n,a1,d);
                break;
            
            case "G":
            case "g":
                System.out.println("Ingrese n, a1 y r");
                n = entrada.nextInt();
                a1 = entrada.nextInt();
                r = entrada.nextInt();
                generar_numerosGeometrica(n,a1,r);
                break;
                
            default:
            System.out.println("La letra no corresponde");
        }
        
    }
    


public static int generar_numerosAritmetica(int n, int a1, int d){

        if(n==0){
            return 0;
        }
        else{
           int an = a1+d*(n-1);
           System.out.println(an);
           an=generar_numerosAritmetica(n-1,a1,d);
        }
        return 0;
}

public static double generar_numerosGeometrica(int n, int a1, int r){

        if(n==0){
            return 0;
        }
        else{
           double an = a1 * Math.pow(r ,(n-1));
           System.out.println(an);
           an=generar_numerosAritmetica(n-1,a1,r);
        }
        return 0;
}
}